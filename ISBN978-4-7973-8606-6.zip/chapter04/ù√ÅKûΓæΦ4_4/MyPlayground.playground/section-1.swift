func areaOfSquareWithSideLength(sideLength:Int) {
    print(sideLength * sideLength)
}
areaOfSquareWithSideLength(3)