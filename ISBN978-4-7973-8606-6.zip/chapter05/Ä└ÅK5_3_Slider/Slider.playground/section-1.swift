// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var slider = UISlider()
slider.value = 0.5
slider.setValue(0.5, animated: true)