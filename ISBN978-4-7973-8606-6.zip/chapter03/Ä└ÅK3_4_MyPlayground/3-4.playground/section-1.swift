for x in 1...9 {
    for n in 1...9 {
        print(x * n)
    }
}
