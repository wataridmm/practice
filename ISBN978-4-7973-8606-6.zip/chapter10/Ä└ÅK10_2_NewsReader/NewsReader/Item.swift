//
//  Item.swift
//  NewsReader
//
//  Created by 高橋京介 on 2015/10/30.
//  Copyright © 2015年 mycompany. All rights reserved.
//

import Foundation

class Item {
    var title = ""
    var link = ""
}